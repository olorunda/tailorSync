<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label' => null,
    'disabled' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label' => null,
    'disabled' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div <?php echo e($attributes->only(['class'])->class('flex items-center')); ?>>
    <input
        <?php echo e($attributes->except(['class'])); ?>

        type="checkbox"
        <?php if($disabled): ?> disabled <?php endif; ?>
        class="h-4 w-4 rounded border-zinc-300 text-orange-600 focus:ring-orange-500/50 disabled:opacity-50 dark:border-zinc-700 dark:bg-zinc-900 dark:focus:ring-orange-500/50"
    >

    <?php if($label): ?>
        <label for="<?php echo e($attributes->get('id') ?? $attributes->wire('model')->value()); ?>" class="ml-2 block text-sm text-zinc-700 dark:text-zinc-300">
            <?php echo e($label); ?>

        </label>
    <?php endif; ?>

    <?php $__errorArgs = [$attributes->wire('model')->value()];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="mt-1 text-sm text-red-600 dark:text-red-500"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH /Users/olaoluwa/PhpstormProjects/tailorit/wtailorfit/resources/views/flux/checkbox.blade.php ENDPATH**/ ?>