
<ui-close data-flux-modal-close>
    <?php echo e($slot); ?>

</ui-close>
<?php /**PATH /Users/olaoluwa/PhpstormProjects/tailorit/wtailorfit/vendor/livewire/flux/stubs/resources/views/flux/modal/close.blade.php ENDPATH**/ ?>