<?php

use App\Models\Client;
use App\Models\Invoice;
use App\Models\Order;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Livewire\Volt\Component;

?>

<div class="w-full">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-2xl font-bold text-zinc-900 dark:text-zinc-100">Edit Invoice</h1>
            <p class="text-zinc-600 dark:text-zinc-400">Update invoice #<?php echo e($invoice->invoice_number); ?></p>
        </div>
        <div class="flex items-center gap-3">
            <a href="<?php echo e(route('invoices.show', $invoice)); ?>" class="inline-flex items-center px-4 py-2 bg-zinc-200 dark:bg-zinc-700 hover:bg-zinc-300 dark:hover:bg-zinc-600 text-zinc-900 dark:text-zinc-100 rounded-md text-sm font-medium transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                </svg>
                Back to Invoice
            </a>
        </div>
    </div>

    <form wire:submit="save" class="space-y-6">
        <?php if($invoice->status === 'paid'): ?>
        <div class="bg-yellow-50 dark:bg-yellow-900/30 border-l-4 border-yellow-400 p-4 mb-4">
            <div class="flex">
                <div class="flex-shrink-0">
                    <svg class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-yellow-700 dark:text-yellow-200">
                        This invoice is marked as paid. You can only change its status to pending. To make other changes, first change the status to pending.
                    </p>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if(session()->has('error')): ?>
        <div class="bg-red-50 dark:bg-red-900/30 border-l-4 border-red-400 p-4 mb-4">
            <div class="flex">
                <div class="flex-shrink-0">
                    <svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-red-700 dark:text-red-200">
                        <?php echo e(session('error')); ?>

                    </p>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="bg-white dark:bg-zinc-800 rounded-xl shadow-sm overflow-hidden p-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Invoice Information -->
                <div>
                    <h2 class="text-lg font-medium text-zinc-900 dark:text-zinc-100 mb-4">Invoice Information</h2>

                    <div class="space-y-4">
                        <div>
                            <label for="invoice_number" class="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Invoice Number <span class="text-red-500">*</span></label>
                            <input wire:model="invoice_number" type="text" id="invoice_number" class="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm" required <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>>
                            <?php $__errorArgs = ['invoice_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label for="status" class="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Status <span class="text-red-500">*</span></label>
                            <select wire:model="status" id="status" class="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm" required>
                                <option value="draft">Draft</option>
                                <option value="pending">Pending</option>
                                <option value="paid">Paid</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label for="invoice_date" class="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Invoice Date <span class="text-red-500">*</span></label>
                                <input wire:model="invoice_date" type="date" id="invoice_date" class="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm" required <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>>
                                <?php $__errorArgs = ['invoice_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div>
                                <label for="due_date" class="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Due Date <span class="text-red-500">*</span></label>
                                <input wire:model="due_date" type="date" id="due_date" class="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm" required <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>>
                                <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div>
                            <label for="description" class="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Description</label>
                            <textarea wire:model="description" id="description" rows="2" class="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm" <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <!-- Client Information -->
                <div>
                    <h2 class="text-lg font-medium text-zinc-900 dark:text-zinc-100 mb-4">Client Information</h2>

                    <div class="space-y-4">
                        <div>
                            <label for="client_id" class="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Select Client</label>
                            <select wire:change="selectClient($event.target.value)" id="client_id" class="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm" <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>>
                                <option value="">Select a client</option>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($client->id); ?>" <?php echo e($client_id == $client->id ? 'selected' : ''); ?>><?php echo e($client->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div>
                            <label for="order_id" class="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Select Order (Optional)</label>
                            <select wire:change="selectOrder($event.target.value)" id="order_id" class="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm" <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>>
                                <option value="">Select an order</option>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($order->id); ?>" <?php echo e($order_id == $order->id ? 'selected' : ''); ?>><?php echo e($order->order_number); ?> - <?php echo e($order->client->name ?? 'Unknown'); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div>
                            <label for="client_name" class="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Client Name <span class="text-red-500">*</span></label>
                            <input wire:model="client_name" type="text" id="client_name" class="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm" required <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>>
                            <?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label for="client_email" class="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Client Email</label>
                            <input wire:model="client_email" type="email" id="client_email" class="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm" <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>>
                            <?php $__errorArgs = ['client_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label for="client_address" class="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Client Address</label>
                            <textarea wire:model="client_address" id="client_address" rows="2" class="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm" <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>></textarea>
                            <?php $__errorArgs = ['client_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Invoice Items -->
        <div class="bg-white dark:bg-zinc-800 rounded-xl shadow-sm overflow-hidden p-6">
            <h2 class="text-lg font-medium text-zinc-900 dark:text-zinc-100 mb-4">Invoice Items</h2>

            <div class="overflow-x-auto">
                <table class="responsive-table min-w-full divide-y divide-zinc-200 dark:divide-zinc-700">
                    <thead>
                        <tr>
                            <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-zinc-500 dark:text-zinc-300 uppercase tracking-wider">Description</th>
                            <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-zinc-500 dark:text-zinc-300 uppercase tracking-wider w-24">Quantity</th>
                            <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-zinc-500 dark:text-zinc-300 uppercase tracking-wider w-32">Unit Price</th>
                            <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-zinc-500 dark:text-zinc-300 uppercase tracking-wider w-32">Amount</th>
                            <th scope="col" class="px-4 py-3 text-right text-xs font-medium text-zinc-500 dark:text-zinc-300 uppercase tracking-wider w-16">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-zinc-200 dark:divide-zinc-700">
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-4 py-2" data-label="Description">
                                    <input
                                        wire:model="items.<?php echo e($index); ?>.description"
                                        type="text"
                                        class="block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm"
                                        placeholder="Item description"
                                        required
                                        <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>

                                    >
                                    <?php $__errorArgs = ["items.{$index}.description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                                <td class="px-4 py-2" data-label="Quantity">
                                    <input
                                        wire:model="items.<?php echo e($index); ?>.quantity"
                                        type="number"
                                        min="0.01"
                                        step="0.01"
                                        class="block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm"
                                        required
                                        <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>

                                    >
                                    <?php $__errorArgs = ["items.{$index}.quantity"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                                <td class="px-4 py-2" data-label="Unit Price">
                                    <div class="relative">
                                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                            <span class="text-zinc-500 dark:text-zinc-400 sm:text-sm">$</span>
                                        </div>
                                        <input
                                            wire:model="items.<?php echo e($index); ?>.unit_price"
                                            type="number"
                                            min="0"
                                            step="0.01"
                                            class="pl-7 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm"
                                            required
                                            <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>

                                        >
                                    </div>
                                    <?php $__errorArgs = ["items.{$index}.unit_price"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                                <td class="px-4 py-2" data-label="Amount">
                                    <div class="relative">
                                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                            <span class="text-zinc-500 dark:text-zinc-400 sm:text-sm">$</span>
                                        </div>
                                        <input
                                            type="number"
                                            value="<?php echo e($item['quantity'] * $item['unit_price']); ?>"
                                            class="pl-7 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm bg-zinc-50 dark:bg-zinc-800"
                                            readonly
                                        >
                                    </div>
                                </td>
                                <td class="px-4 py-2 text-right" data-label="Action">
                                    <button
                                        type="button"
                                        wire:click="removeItem(<?php echo e($index); ?>)"
                                        class="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300"
                                        <?php echo e(count($items) <= 1 || $invoice->status === 'paid' ? 'disabled' : ''); ?>

                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                            <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" />
                                        </svg>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                <button
                    type="button"
                    wire:click="addItem"
                    class="inline-flex items-center px-3 py-2 border border-zinc-300 dark:border-zinc-600 shadow-sm text-sm leading-4 font-medium rounded-md text-zinc-700 dark:text-zinc-200 bg-white dark:bg-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
                    <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>

                >
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd" />
                    </svg>
                    Add Item
                </button>
            </div>

            <div class="mt-6 flex justify-end">
                <div class="w-full md:w-1/3 space-y-3">
                    <div class="flex justify-between">
                        <span class="text-sm font-medium text-zinc-700 dark:text-zinc-300">Subtotal:</span>
                        <span class="text-sm text-zinc-900 dark:text-zinc-100">$<?php echo e(number_format($subtotal, 2)); ?></span>
                    </div>

                    <div class="flex items-center justify-between">
                        <label for="tax_rate" class="text-sm font-medium text-zinc-700 dark:text-zinc-300">Tax Rate (%):</label>
                        <div class="w-24">
                            <input
                                wire:model.live="tax_rate"
                                type="number"
                                min="0"
                                step="0.01"
                                id="tax_rate"
                                class="block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm"
                                <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>

                            >
                        </div>
                    </div>

                    <div class="flex justify-between">
                        <span class="text-sm font-medium text-zinc-700 dark:text-zinc-300">Tax Amount:</span>
                        <span class="text-sm text-zinc-900 dark:text-zinc-100">$<?php echo e(number_format($tax_amount, 2)); ?></span>
                    </div>

                    <div class="flex items-center justify-between">
                        <label for="discount_amount" class="text-sm font-medium text-zinc-700 dark:text-zinc-300">Discount:</label>
                        <div class="w-24 relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <span class="text-zinc-500 dark:text-zinc-400 sm:text-sm">$</span>
                            </div>
                            <input
                                wire:model.live="discount_amount"
                                type="number"
                                min="0"
                                step="0.01"
                                id="discount_amount"
                                class="pl-7 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm"
                                <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>

                            >
                        </div>
                    </div>

                    <div class="flex justify-between pt-3 border-t border-zinc-200 dark:border-zinc-700">
                        <span class="text-base font-medium text-zinc-900 dark:text-zinc-100">Total:</span>
                        <span class="text-base font-bold text-orange-600 dark:text-orange-500">$<?php echo e(number_format($total_amount, 2)); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Additional Information -->
        <div class="bg-white dark:bg-zinc-800 rounded-xl shadow-sm overflow-hidden p-6">
            <h2 class="text-lg font-medium text-zinc-900 dark:text-zinc-100 mb-4">Additional Information</h2>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="notes" class="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Notes</label>
                    <textarea wire:model="notes" id="notes" rows="3" class="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm" placeholder="Notes visible to client" <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>></textarea>
                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="terms" class="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Terms & Conditions</label>
                    <textarea wire:model="terms" id="terms" rows="3" class="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm" placeholder="Payment terms and conditions" <?php echo e($invoice->status === 'paid' ? 'disabled' : ''); ?>></textarea>
                    <?php $__errorArgs = ['terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <div class="flex justify-end">
            <a href="<?php echo e(route('invoices.show', $invoice)); ?>" class="inline-flex justify-center py-2 px-4 border border-zinc-300 dark:border-zinc-600 shadow-sm text-sm font-medium rounded-md text-zinc-700 dark:text-zinc-200 bg-white dark:bg-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 mr-3">
                Cancel
            </a>
            <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-orange-600 hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500">
                Save Changes
            </button>
        </div>
    </form>
</div><?php /**PATH /Users/olaoluwa/PhpstormProjects/tailorit/wtailorfit/resources/views/livewire/invoices/edit.blade.php ENDPATH**/ ?>