<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['action', 'method' => 'POST']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['action', 'method' => 'POST']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<form <?php echo e($attributes->merge(['action' => $action, 'method' => $method === 'GET' ? 'GET' : 'POST', 'data-offline' => 'true'])); ?>>
    <?php if($method !== 'GET' && $method !== 'POST'): ?>
        <?php echo method_field($method); ?>
    <?php endif; ?>

    <?php echo csrf_field(); ?>

    <?php echo e($slot); ?>

</form>
<?php /**PATH /Users/olaoluwa/PhpstormProjects/tailorit/wtailorfit/resources/views/components/offline-form.blade.php ENDPATH**/ ?>