<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </head>
    <body class="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-zinc-900 dark:to-zinc-800 text-zinc-900 dark:text-zinc-100 min-h-screen antialiased">
        <header class="w-full max-w-7xl mx-auto px-4 py-6 flex justify-between items-center">
            <div class="flex items-center">
                <a href="<?php echo e(route('home')); ?>" wire:navigate>
                    <div class="text-3xl font-bold text-orange-600 dark:text-orange-500">TailorSync</div>
                </a>
            </div>

            <nav class="flex items-center gap-4">
                <?php if(Route::has('login') && Route::currentRouteName() !== 'login'): ?>
                    <a
                        href="<?php echo e(route('login')); ?>"
                        class="inline-block px-5 py-2 text-orange-600 dark:text-orange-500 hover:text-orange-800 dark:hover:text-orange-400 rounded-md text-sm font-medium transition-colors"
                        wire:navigate
                    >
                        Log in
                    </a>
                <?php endif; ?>

                <?php if(Route::has('register') && Route::currentRouteName() !== 'register'): ?>
                    <a
                        href="<?php echo e(route('register')); ?>"
                        class="inline-block px-5 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-md text-sm font-medium transition-colors"
                        wire:navigate
                    >
                        Register
                    </a>
                <?php endif; ?>
            </nav>
        </header>

        <main class="max-w-7xl mx-auto px-4 py-8">
            <div class="flex min-h-[calc(100vh-300px)] flex-col items-center justify-center gap-6 p-6 md:p-10">
                <div class="flex w-full max-w-sm flex-col gap-2 bg-white dark:bg-zinc-800 p-8 rounded-xl shadow-md">
                    <a href="<?php echo e(route('home')); ?>" class="flex flex-col items-center gap-2 font-medium" wire:navigate>
                        <span class="flex h-9 w-9 mb-1 items-center justify-center rounded-md">
                            <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['class' => 'size-9 fill-current text-orange-600 dark:text-orange-500']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-9 fill-current text-orange-600 dark:text-orange-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
                        </span>
                        <span class="text-xl font-bold text-orange-600 dark:text-orange-500">TailorSync</span>
                    </a>
                    <div class="flex flex-col gap-6">
                        <?php echo e($slot); ?>

                    </div>
                </div>
            </div>
        </main>

        <footer class="bg-zinc-100 dark:bg-zinc-900 py-8 mt-auto">
            <div class="max-w-7xl mx-auto px-4">
                <div class="flex flex-col md:flex-row justify-between items-center">
                    <div class="mb-6 md:mb-0">
                        <div class="text-2xl font-bold text-orange-600 dark:text-orange-500 mb-2">TailorSync</div>
                        <p class="text-zinc-600 dark:text-zinc-400">Tailoring Management System</p>
                    </div>
                </div>
                <div class="border-t border-zinc-200 dark:border-zinc-800 mt-8 pt-8 text-center text-zinc-500 dark:text-zinc-400">
                    <p>&copy; <?php echo e(date('Y')); ?> TailorSync. All rights reserved.</p>
                </div>
            </div>
        </footer>
        <?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?>

    </body>
</html>
<?php /**PATH /Users/olaoluwa/PhpstormProjects/tailorit/wtailorfit/resources/views/components/layouts/auth/simple.blade.php ENDPATH**/ ?>