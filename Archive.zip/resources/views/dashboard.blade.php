<x-layouts.app :title="__('Dashboard')">
    @livewire('dashboard.index')
</x-layouts.app>
